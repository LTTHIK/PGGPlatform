# Mixed Format Ingest for GraphRAG

This folder converts mixed file formats into GraphRAG-ready text files under `input/normalized/`.

## 1) Install dependencies

```bash
cd /home/aqi/graphrag/glm_zai_demo
pip install -r ingest/requirements.txt
```

For OCR on images, also install system tesseract:

```bash
sudo apt-get update && sudo apt-get install -y tesseract-ocr tesseract-ocr-chi-sim
```

## 2) Convert mixed files

Example source directory:

```bash
python ingest/convert_to_graphrag_input.py \
  --source-dir /home/aqi/graphrag/glm_zai_demo/data \
  --target-dir /home/aqi/graphrag/glm_zai_demo/input/normalized \
  --enable-ocr
```

If you do not need OCR, remove `--enable-ocr`.

## 3) Re-index with GraphRAG

```bash
cd /home/aqi/graphrag/glm_zai_demo
graphrag index
```

## Notes

- `pdf/pptx/docx` are converted by `markitdown`.
- `csv/xlsx` are flattened into row-wise text records.
- `html` is converted via visible text extraction.
- Output file format includes source metadata header and content body.
