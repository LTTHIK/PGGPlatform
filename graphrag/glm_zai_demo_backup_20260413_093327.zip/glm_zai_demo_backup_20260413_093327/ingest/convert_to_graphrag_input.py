#!/usr/bin/env python3
"""
Convert mixed file types into GraphRAG text inputs.

Supported by default:
- txt, md, csv, xls, xlsx, html, htm
- pdf, pptx, docx (via markitdown if available)
- images (png/jpg/jpeg/webp) with optional OCR (pytesseract + Pillow)
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Iterable


TEXT_EXTS = {".txt", ".md"}
HTML_EXTS = {".html", ".htm"}
CSV_EXTS = {".csv"}
EXCEL_EXTS = {".xlsx", ".xls"}
MARKITDOWN_EXTS = {".pdf", ".pptx", ".docx"}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}


def _safe_read_text(path: Path) -> str:
    # 尽量按常见编码读取文本，最大化兼容不同来源文件。
    for enc in ("utf-8", "utf-8-sig", "gb18030", "latin-1"):
        try:
            return path.read_text(encoding=enc)
        except Exception:
            continue
    return path.read_text(errors="ignore")


def _convert_csv(path: Path) -> str:
    # 将 CSV 行转成 “key=value” 文本，便于后续向量化与实体关系抽取。
    rows: list[str] = []
    with path.open("r", encoding="utf-8", errors="ignore", newline="") as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader, start=1):
            compact = "; ".join(f"{k}={v}" for k, v in row.items())
            rows.append(f"row={i} | {compact}")
    return "\n".join(rows)


def _convert_excel(path: Path) -> str:
    import pandas as pd  # lazy import

    # 每个 sheet 单独加标题，再逐行转为文本记录。
    blocks: list[str] = []
    sheets = pd.read_excel(path, sheet_name=None)
    for sheet, df in sheets.items():
        blocks.append(f"# sheet: {sheet}")
        for i, row in enumerate(df.fillna("").to_dict(orient="records"), start=1):
            compact = "; ".join(f"{k}={v}" for k, v in row.items())
            blocks.append(f"row={i} | {compact}")
    return "\n".join(blocks)


def _convert_html(path: Path) -> str:
    from bs4 import BeautifulSoup  # lazy import

    # 仅提取页面可见文本，去掉 HTML 标签结构。
    html = _safe_read_text(path)
    soup = BeautifulSoup(html, "html.parser")
    return soup.get_text("\n", strip=True)


def _convert_with_markitdown(path: Path) -> str:
    from markitdown import MarkItDown  # lazy import

    # 复用 markitdown 统一处理 office/pdf 等复杂格式。
    md = MarkItDown()
    result = md.convert(str(path))
    return getattr(result, "text_content", "") or ""


def _convert_image_with_ocr(path: Path) -> str:
    import pytesseract  # lazy import
    from PIL import Image  # lazy import

    # OCR: 默认中英双语识别。需要系统安装 tesseract 与中文语言包。
    img = Image.open(path)
    return pytesseract.image_to_string(img, lang="chi_sim+eng")


def convert_one(path: Path, enable_ocr: bool) -> str:
    # 按扩展名分流到对应转换器，未支持或空内容返回空字符串。
    ext = path.suffix.lower()
    if ext in TEXT_EXTS:
        return _safe_read_text(path)
    if ext in CSV_EXTS:
        return _convert_csv(path)
    if ext in EXCEL_EXTS:
        return _convert_excel(path)
    if ext in HTML_EXTS:
        return _convert_html(path)
    if ext in MARKITDOWN_EXTS:
        return _convert_with_markitdown(path)
    if ext in IMAGE_EXTS:
        if not enable_ocr:
            return ""
        return _convert_image_with_ocr(path)
    return ""


def build_output_text(src: Path, content: str) -> str:
    # 输出统一结构：metadata + content，方便追溯来源与后续审计。
    header = {
        "source_file": str(src),
        "filename": src.name,
        "suffix": src.suffix.lower(),
    }
    return f"---metadata---\n{json.dumps(header, ensure_ascii=False)}\n---content---\n{content.strip()}\n"


def iter_files(root: Path, patterns: Iterable[str]) -> Iterable[Path]:
    # 支持多个 glob 模式，递归扫描来源目录。
    for pattern in patterns:
        yield from root.rglob(pattern)


def main() -> int:
    # CLI 参数：source-dir 必填；target-dir 默认写到 GraphRAG input/normalized。
    parser = argparse.ArgumentParser(description="Convert mixed files to GraphRAG input text files.")
    parser.add_argument("--source-dir", required=True, help="Directory containing source files.")
    parser.add_argument(
        "--target-dir",
        default="/home/aqi/graphrag/glm_zai_demo/input/normalized",
        help="Directory to write normalized .txt files.",
    )
    parser.add_argument(
        "--enable-ocr",
        action="store_true",
        help="Enable OCR for image files (requires pytesseract + Pillow + system tesseract).",
    )
    args = parser.parse_args()

    source = Path(args.source_dir).resolve()
    target = Path(args.target_dir).resolve()
    target.mkdir(parents=True, exist_ok=True)

    # 统一可处理的文件后缀；新增格式时在这里追加即可。
    patterns = ["*.txt", "*.md", "*.csv", "*.xlsx", "*.xls", "*.html", "*.htm", "*.pdf", "*.pptx", "*.docx", "*.png", "*.jpg", "*.jpeg", "*.webp"]
    files = sorted(set(iter_files(source, patterns)))

    converted = 0
    skipped = 0
    for f in files:
        try:
            content = convert_one(f, enable_ocr=args.enable_ocr)
            if not content.strip():
                # 无内容（或 OCR 关闭的图片）视为跳过，不中断全局流程。
                skipped += 1
                continue
            # 用 “文件名 + 路径哈希” 命名，避免同名文件覆盖。
            out_name = f"{f.stem}_{abs(hash(str(f))) % (10**8)}.txt"
            (target / out_name).write_text(build_output_text(f, content), encoding="utf-8")
            converted += 1
        except Exception as e:
            # 单文件失败只告警并继续，避免批处理被一个脏文件阻塞。
            skipped += 1
            print(f"[WARN] skip {f}: {e}")

    print(f"done: converted={converted}, skipped={skipped}, output={target}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

