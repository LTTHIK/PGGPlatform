# GraphRAG Demo 实战手册（`glm_zai_demo`）

本文档是当前工程的实操版说明，覆盖：

- 全量建库（`data -> output`）
- 增量更新（`data_increment -> output_increment_*`）
- 查询与可视化（包含已验证可用命令）
- 常见报错与排查

---

## 1. 项目目录

```text
glm_zai_demo/
├── .env
├── settings.yaml
├── data/                               # 主数据集
├── data_increment/                     # 增量原始数据（目录结构可与 data 不同，见 §3）
├── ingest/
│   ├── convert_to_graphrag_input.py
│   └── requirements.txt
├── input/normalized/                   # 预处理后文本
├── output/                             # 主库产物
├── output_increment_时间戳/             # 增量归档目录
├── update_output/                      # update 临时输出
├── incremental_update.py
└── visualize_graph.py
```

---

## 2. 环境准备

```bash
conda activate graphrag311
pip install -r ingest/requirements.txt
```

`.env` 至少包含：

```dotenv
ZAI_API_KEY=你的密钥
```

---

## 3. 支持数据格式

输入支持：

- 文档：`docx`, `pdf`, `pptx`
- 表格：`xlsx`, `xls`, `csv`
- 图片：`png`, `jpg`, `jpeg`, `webp`（可选 OCR）
- 文本/网页：`txt`, `md`, `html`, `htm`

### `data` 与 `data_increment` 目录结构要不要一致？

**不必完全一致。** `convert_to_graphrag_input.py` 会**递归扫描** `--source-dir` 下所有支持的扩展名，**不强制**必须有 `docx/`、`excel/` 等固定子目录名；增量文件可以放在 `data_increment/` 下任意子路径（或自定义层级），只要扩展名在支持列表中即可。

建议与 `data` **同构**仅为方便对照和维护，不是 GraphRAG 或脚本的硬性要求。索引实际读的是 **`input/normalized`** 里符合 `settings.yaml` 中 `input.file_pattern` 的 txt，与你在 `data` / `data_increment` 里如何分子目录无关。

**推荐（可选）** 与全量侧对齐的示例结构：

```text
data_increment/
├── docx/
├── excel/
├── images/
├── pdf/
└── pptx/
```

---

## 4. 全量流程（主库）

### 4.1 预处理

```bash
python ingest/convert_to_graphrag_input.py \
  --source-dir ./data \
  --target-dir ./input/normalized
```

如需图片 OCR：

```bash
python ingest/convert_to_graphrag_input.py \
  --source-dir ./data \
  --target-dir ./input/normalized \
  --enable-ocr
```

### 4.2 建库

```bash
graphrag index --skip-validation
```

### 4.3 查询主库

```bash
graphrag query "你的问题" --method basic
```

---

## 5. 增量流程（保留旧库）

### 5.1 一键增量更新

```bash
python incremental_update.py \
  --source-dir ./data_increment \
  --run-update \
  --skip-validation
```

脚本会：

1. 预处理增量文件
2. 执行 `graphrag update`
3. 把 `update_output` 归档到 `output_increment_时间戳`

### 5.2 关键路径规则（非常重要）

增量归档是分层结构：

```text
output_increment_时间戳/
└── 运行批次时间戳/
    ├── delta/
    └── previous/
```

查询与可视化必须指向 `delta`，不能只指向 `output_increment_时间戳` 根目录。  
否则会报：

`ValueError: Could not find text_units.parquet in storage!`

### 5.3 查询增量融合库（已验证）

```bash
graphrag query "近一年哪些公司有融资事件？" --method basic \
  -d ./output_increment_20260409_212025/20260409-212051/delta

graphrag query "与冷链物流相关的企业和合作方有哪些？" --method basic \
  -d ./output_increment_20260409_212025/20260409-212051/delta
```

### 5.4 融合图谱（`delta`）是否包含主库？

**可以这么理解：`delta` 里的图谱是「主库 + 本次增量」合并后的整库快照，不是「只有新增文件那一小块」。**

- **`graphrag update`** 是在当前 **`output/` 对应的主库状态**上继续跑流水线，把新文档纳入索引与图谱。
- **`…/delta/`**：本次 update **完成之后**的完整产物目录（含 `graph.graphml`、parquet、向量库等），对应 **合并后的知识状态**。
- **`…/previous/`**：本次 update **开始之前**的快照，便于对比或回滚理解。
- **`output/graph.graphml`**：上一次 **`graphrag index`（全量建库）** 时的图谱；只要你没有再次全量 `index`，它通常 **不会** 被增量脚本改写，仍是「当时那一版主库」的图。

因此：

- 要看 **「主库 + 增量合在一起」** 的图：用 **`delta/graph.graphml`**（与查询时 `-d …/delta` 一致）。
- 要看 **「纯主库当时那一版」** 的图：用 **`output/graph.graphml`**。

---

## 6. 知识图谱可视化

### 6.1 主库图谱

```bash
python visualize_graph.py \
  --graph ./output/graph.graphml \
  --topk 50 \
  --show-edge-weight \
  --out ./graph_preview_main_output.png
```

### 6.2 增量融合图谱

```bash
python visualize_graph.py \
  --graph ./output_increment_20260409_212025/20260409-212051/delta/graph.graphml \
  --topk 80 \
  --show-edge-weight \
  --out ./graph_one_merged.png
```

这条命令已经在当前环境验证通过，图片可正常保存。

### 6.3 交互式 HTML（可选）

```bash
python -m pip install pyvis
python visualize_graph.py \
  --graph ./output_increment_20260409_212025/20260409-212051/delta/graph.graphml \
  --topk 80 \
  --html-out ./graph_merged.html \
  --out ./graph_merged.png
```

---

## 7. 常见提示与处理

### 7.1 `LiteLLM ... Network is unreachable`

这是远程价格表拉取失败告警，不影响检索和推理，可忽略。

### 7.2 中文字体 `Glyph missing from font(s) DejaVu Sans`

图已保存，但终端会刷字体告警。属于显示层问题，不影响索引和查询。  
若要减少告警：

- 安装中文字体（例如 `fonts-noto-cjk`）
- 或将图标题改英文

### 7.3 `plt.show()` 阻塞

`visualize_graph.py` 最后会调用 `plt.show()`，保存图片后终端可能停在窗口。  
看到 `已保存:` 后即可关闭图窗或 `Ctrl+C`。

---

## 8. 快速命令清单（推荐复制）

```bash
# 1) 全量建库
python ingest/convert_to_graphrag_input.py --source-dir ./data --target-dir ./input/normalized
graphrag index --skip-validation

# 2) 增量更新
python incremental_update.py --source-dir ./data_increment --run-update --skip-validation

# 3) 查询增量融合库（必须指向 delta）
graphrag query "你的问题" --method basic -d ./output_increment_时间戳/运行批次时间戳/delta

# 4) 可视化增量融合图谱
python visualize_graph.py --graph ./output_increment_时间戳/运行批次时间戳/delta/graph.graphml --topk 80 --show-edge-weight --out ./graph_one_merged.png
```

